//
//  EmojiContainer.swift
//  emojiForest
//
//  Created by akbar  Rizvi on 1/29/20.
//  Copyright © 2020 akbar  Rizvi. All rights reserved.
//

import Foundation

struct EmojisContainer: Codable {
    let emojis: [String]
}
