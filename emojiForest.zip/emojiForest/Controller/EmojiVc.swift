//
//  ViewController.swift
//  emojiForest
//
//  Created by akbar  Rizvi on 1/29/20.
//  Copyright © 2020 akbar  Rizvi. All rights reserved.
//

import UIKit

var segueIdentifier = "goToEmojiGameVC"

class EmojiVc: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var allEmojis: EmojisContainer? // optional type declaration
    
    override func viewDidLoad() {
        collectionView.dataSource = self
        collectionView.delegate = self
        //    print(EmojisContainer)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let urlString = "https://emojigenerator.herokuapp.com/emojis/api/v1?count=10"
        guard let url = URL(string: urlString) else { return }
        
        // 2
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error!.localizedDescription)
            }
            
            guard let data = data else { return }
            // 3
            //Decode data
            
            self.allEmojis = try? JSONDecoder().decode(EmojisContainer.self, from: data)
            
            
            
            // 4
            //Get back to the main queue
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
            
            
            // 5
            }.resume() // fires of request
        
    }
    
    
    
    
}

extension EmojiVc: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let emojis = allEmojis else { return 0 }
        
        return emojis.emojis.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! EmojiCollectionViewCell
        
        
        cell.avator.text = allEmojis?.emojis[indexPath.item]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if (collectionView.cellForItem(at: indexPath) as? EmojiCollectionViewCell) != nil {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let chatVC = storyboard.instantiateViewController(withIdentifier: "goToEmojiGameVC") as! emojiGameVC
            
            
            present(chatVC, animated: true, completion: nil)
            
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width/2 - 2, height: collectionView.frame.size.width/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1  }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 4
    }
    
}
